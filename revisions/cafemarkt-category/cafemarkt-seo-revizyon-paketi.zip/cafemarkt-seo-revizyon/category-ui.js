/* Yalnız görsel davranış. Canonical, metadata ve JSON-LD sunucuda üretilmelidir. */
(() => {
  const path = '/pasta-soguk-teshir-dolaplari';
  if (location.pathname.replace(/\/$/, '') !== path) return;
  function init() {
    document.body.classList.add('cm-category-554');
    const filter = document.querySelector('.folder-filter #product-filter');
    if (!filter || document.getElementById('cm-filter-details')) return;
    const details = document.createElement('details');
    details.id = 'cm-filter-details';
    details.className = 'cm-filter-details';
    const summary = document.createElement('summary');
    summary.textContent = 'Kategori ve ürün filtreleri';
    filter.before(details);
    details.append(summary, filter);
    const mobile = window.matchMedia('(max-width: 767px)');
    const sync = () => { details.open = !mobile.matches; };
    sync();
    mobile.addEventListener('change', sync);
    // Mevcut mobil Filtre bağlantısı aynı paneli açar; Vue düğümü korunur.
    document.querySelectorAll('a[href="#product-filter"]').forEach(link => {
      link.addEventListener('click', event => {
        if (!mobile.matches) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        details.open = true;
        summary.focus();
        details.scrollIntoView({block: 'start', behavior: 'auto'});
      }, true);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
  else init();
})();
