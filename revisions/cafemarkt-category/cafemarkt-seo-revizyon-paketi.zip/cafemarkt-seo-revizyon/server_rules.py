"""Platformdan bağımsız entegrasyon referansı. T-Soft'a doğrudan Python yüklenmez.
Tema kaynakları alınmadan platformun şablon diline çevrilmiş kabul edilmemelidir.
"""
from copy import deepcopy
from urllib.parse import parse_qs
from datetime import datetime
from xml.etree import ElementTree as ET
BASE = 'https://www.cafemarkt.com/pasta-soguk-teshir-dolaplari'
ALTERNATES = {'tr': BASE,
              'en':'https://www.cafemarkt.com/refrigerated-display-cabinets-en',
              'ar':'https://www.cafemarkt.com/refrigerated-display-cabinets-ar',
              'ru':'https://www.cafemarkt.com/refrigerated-display-cabinets-ru',
              'x-default': BASE}

def sitemap_category_entry(content_published_at):
    """Yalnız ana TR URL girdisi; tüm sitemap'in yerine konmaz.
    Zaman, gerçek yayın kaydından gelmeli; build/şimdiki zaman kullanılmaz.
    """
    published = datetime.fromisoformat(content_published_at)
    if published.tzinfo is None:
        raise ValueError('Yayın zamanı saat dilimi içermeli')
    namespace = 'http://www.sitemaps.org/schemas/sitemap/0.9'
    xhtml = 'http://www.w3.org/1999/xhtml'
    ET.register_namespace('', namespace)
    ET.register_namespace('xhtml', xhtml)
    entry = ET.Element(f'{{{namespace}}}url')
    ET.SubElement(entry, f'{{{namespace}}}loc').text = BASE
    for lang, url in ALTERNATES.items():
        ET.SubElement(entry, f'{{{xhtml}}}link', {'rel':'alternate', 'hreflang':lang, 'href':url})
    ET.SubElement(entry, f'{{{namespace}}}lastmod').text = published.isoformat()
    return ET.tostring(entry, encoding='unicode')

def canonical_for_category(raw_query):
    """Yalnız filtresiz liste. None: mevcut filtre/sıralama kuralını koru."""
    query = parse_qs(raw_query, keep_blank_values=True)
    if set(query) - {'pg'}:
        return None
    values = query.get('pg', ['1'])
    if len(values) != 1 or not values[0].isascii() or not values[0].isdigit():
        raise ValueError('Geçersiz sayfalama; router 4xx/normalizasyon kararı vermeli')
    page = int(values[0])
    if not 1 <= page <= 8:
        raise ValueError('Mevcut kategori için doğrulanmış sayfa aralığı 1–8')
    return BASE if page == 1 else f'{BASE}?pg={page}'

def enrich_graph(original, canonical, description_by_url, name, breadcrumb_name):
    """Canlı fiyat/stok/iade alanlarını değiştirmeden mevcut graph'ı zenginleştirir."""
    if not canonical or not (canonical == BASE or canonical.startswith(BASE + '?pg=')):
        raise ValueError('Bu adaptör yalnız bu kategorinin filtresiz sayfaları içindir')
    result = deepcopy(original)
    graph = result['@graph']
    lists = [node for node in graph if node.get('@type') == 'ItemList']
    if len(lists) != 1:
        raise ValueError('Tek ItemList bekleniyor; şablon ayrıca incelenmeli')
    listing = lists[0]
    listing['@id'] = canonical + '#itemlist'
    for entry in listing.get('itemListElement', []):
        item = entry.get('item', {})
        description = description_by_url.get(item.get('url'))
        if not item.get('description') and description:
            item['description'] = description
    pages = [node for node in graph if node.get('@type') == 'CollectionPage']
    if len(pages) > 1:
        raise ValueError('Birden fazla CollectionPage bulundu')
    page = pages[0] if pages else {}
    page.update({'@type':'CollectionPage','@id':canonical+'#webpage',
                 'url':canonical,'name':name,'inLanguage':'tr',
                 'isPartOf':{'@id':'https://www.cafemarkt.com/#website'},
                 'mainEntity':{'@id':listing['@id']}})
    if not pages: graph.append(page)
    for node in graph:
        if node.get('@type') == 'BreadcrumbList':
            for crumb in node.get('itemListElement', []):
                if crumb.get('item') == BASE:
                    crumb['name'] = breadcrumb_name
    return result
